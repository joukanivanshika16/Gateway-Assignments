package multipleInheritance;

import java.util.Scanner;

public class ImplementInterface implements Human,mutant {
	/*Class ImplementInterface implements Interface Human And mutant
	 */
	
	static int noOfSkills;
	static int noOfPersonality;
	public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	
	System.out.println("----------ENTER HUMAN DETAILS----------");
	System.out.println("Enter Huamn Name:");
	String humanName=sc.next();
	System.out.print("How Many Skills Do You Want To Enter??: ");           
	String[] humanSkills = new String [sc.nextInt()];      
	sc.nextLine();   
	for (noOfSkills = 0; noOfSkills < humanSkills.length; noOfSkills++)   
	{  
	humanSkills[noOfSkills] = sc.nextLine();  
	}
	
	ImplementInterface obj=new ImplementInterface();
	obj.humanDetails(humanName, humanSkills);
	
	
	System.out.println("----------ENTER MUTANT DETAILS----------");
	System.out.println("Enter Mutant Name:");
	String mutantName=sc.next();
	System.out.println("Enter Mutant Ability:");
	String mutantAbility=sc.next();
	System.out.println("Enter Mutant Planet:");
	String mutantPlanet=sc.next();
	obj.mutantDetails(mutantName, mutantAbility, mutantPlanet);
	
	
	System.out.println("-----------ENTER  PERSONALITY DETAILS-------------");
	System.out.print("How Many Personalities You Want To Enter: ");           
	String[] personality = new String [sc.nextInt()];      
	sc.nextLine();   
	for (noOfPersonality = 0; noOfPersonality < personality.length; noOfPersonality++)   
	{  
	personality[noOfPersonality] = sc.nextLine();  
	}  
	obj.personalityDetails(personality);
	}

	@Override
	public void mutantDetails(String name,String ability,String planet) {
		System.out.println("Name:"+name);
		System.out.println("Ability:"+ability);
		System.out.println("Planet:"+planet);
	}

	@Override
	public void personalityDetails(String personalities[]) {
		System.out.println("Your Personality Details Are:");
		for(noOfPersonality=0;noOfPersonality<personalities.length;noOfPersonality++) {
		System.out.println(personalities[noOfPersonality]);
		}
	}

	@Override
	public void humanDetails(String name, String skills[]) {
		System.out.println("HUMAN DETAILS:");
		System.out.println("Your Name:"+name);
		System.out.println("Your Skills Are:");
		for(noOfSkills=0;noOfSkills<skills.length;noOfSkills++) {
		System.out.println(skills[noOfSkills]);
		}
	}
}
