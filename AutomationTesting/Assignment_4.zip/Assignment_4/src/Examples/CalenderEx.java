package Examples;

import java.time.LocalDate;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class CalenderEx {
	/*This program will handle the Calendar by using
	 * Automation Testing*/
	public static void main(String[] args) throws InterruptedException {
		 String gcPath="./drivers/chromedriver.exe";
		 String url="https://www.seleniumeasy.com/test/";
		 System.setProperty("webdriver.chrome.driver", gcPath);

		 	WebDriver gcDriver=new ChromeDriver();
			gcDriver.manage().window().maximize();
			gcDriver.get(url);
			
			Thread.sleep(5000);
			String popupId="at-cv-lightbox-close";
			WebElement popupClose=gcDriver.findElement(By.id(popupId));
			popupClose.click();
			Thread.sleep(2000);
			
			String datePickerXpath="//a[contains(text(),'Date pickers')]";
			WebElement datePicker=gcDriver.findElement(By.xpath(datePickerXpath));
			datePicker.click();
			Thread.sleep(2000);
			
			 String jqueryDatePicker="//ul[@class='dropdown-menu']//a[text()='JQuery Date Picker']";
			 WebElement jDatePicker=gcDriver.findElement(By.xpath(jqueryDatePicker));
			 jDatePicker.click();
			 Thread.sleep(2000);
			
			 	String fromXpath = "//input[@id='from']";
				WebElement from = gcDriver.findElement(By.xpath(fromXpath));
				from.click();
				
				LocalDate date = LocalDate.now();
				int todaysDate = date.getDayOfMonth();
				int currentMonth = date.getMonthValue();
				
				int currentMonthIndex = currentMonth - 1;
				LocalDate nextSevenDate = LocalDate.now().plusDays(8);
				int nextSevenDayDate = nextSevenDate.getDayOfMonth();
				int nextMonth = nextSevenDate.getMonthValue();
				int nextMonthIndex = nextMonth - 1;
				
				String selectMonthXpath = "//select[@class='ui-datepicker-month']";
			    WebElement month = gcDriver.findElement(By.xpath(selectMonthXpath)); 
			    Select selectMonth = new Select(month); 
			    selectMonth.selectByIndex(currentMonthIndex);
				
				String todaysXpath = "//a[text()='"+todaysDate+"']";
				WebElement todayDate = gcDriver.findElement(By.xpath(todaysXpath));
				todayDate.click();
				
				
				String toXpath = "//input[@id='to']";
				WebElement to = gcDriver.findElement(By.xpath(toXpath));
				to.click();
				
				String nextSevenDayXpath = "//a[text()='"+nextSevenDayDate+"']";
				WebElement nextSevenDate1 = gcDriver.findElement(By.xpath(nextSevenDayXpath));
				nextSevenDate1.click();
				
				String selectToMonthXpath = "//select[@class='ui-datepicker-month']";
			    WebElement ToMonth = gcDriver.findElement(By.xpath(selectToMonthXpath)); 
			    Select selectToMonth = new Select(ToMonth); 
			    selectToMonth.selectByIndex(nextMonthIndex);
		    }			
	

}
