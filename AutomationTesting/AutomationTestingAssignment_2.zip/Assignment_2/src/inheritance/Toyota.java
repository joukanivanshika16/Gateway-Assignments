package inheritance;

import java.util.Scanner;

public class Toyota extends Car{
	/*Toyota is a Sub Class of Car which will 
	 * Override the methods of its Parent Class-
	 * Apart from that it has its own two methods:-
	 * Drive() & Brake().
	 */
	
	//Variables
	static int driverInput = 0;
	static int gear = 0;
	static int currentSpeed=0;
	static boolean applyBrake=false;
	static String brakeType;
	
	//Constructor
	public Toyota() {
		super();
	}
	
	//Methods
	public static void  VehicleDetails() {
		System.out.println("VEHICLES DETAILS");
		System.out.println("Vehicle Type: "+vehicleType);
		System.out.println("No Of Wheels: "+noOfWheels);
		System.out.println("Brand Name:"+brandName);
		System.out.println("Engine Type:"+engineType);
		System.out.println("Person Capacity:"+personCapacity);
		System.out.println("Fuel Type:"+fuelType);
		System.out.println("vehicle Color:"+vehicleColor);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Toyota();
		VehicleDetails();
		while(true)
		{
			Scanner sc=new Scanner(System.in);
			System.out.println("\nPress 1 for applying Accelator \nPress 2 for applying Brake \nPress 0 to exit");
			driverInput=sc.nextInt();
			
			if(driverInput == 1) {
				System.out.println("Please Enter Current Speed Of Car:");
				currentSpeed=sc.nextInt();
				System.out.println("Please Apply Gear:");
				gear=sc.nextInt();
				Drive(gear, currentSpeed);
			}
			else if(driverInput == 2)
			{
				applyBrake=true;
				if(applyBrake == true) {
					System.out.println("Please Enter Brake Type(hard/medium/low):");
					brakeType=sc.next();
					System.out.println("Please Enter Current Speed Of Car:");
					currentSpeed=sc.nextInt();
					Brake(brakeType,currentSpeed);
				}
			}
			else if(driverInput == 0) {
				System.out.println("GoodBye!");
				break;
			}
		}
		
	}
	public static void Drive(int gear,int currentSpeed) {
			
			if(currentSpeed == 0)
			{
				startEngine();
			}
			if(gear==1) {
				currentSpeed+=10;
				System.out.println("Current Speed is:"+currentSpeed);
			}
			else if (gear==2){
				currentSpeed+=20;
				System.out.println("Current Speed is:"+currentSpeed);
			}
			else if (gear==3 || gear==4 || gear==5){
				currentSpeed+=30;
				System.out.println("Current Speed is:"+currentSpeed);
			}
			else {
				System.out.println("Enter Valid Gear");
			}
	    }
	public static void Brake(String braketype, int currentSpeed) {
		if(braketype.contentEquals("hard"))
		{
			currentSpeed -= 40;
			currentSpeed = currentSpeed <= 0 ? 0 : currentSpeed;
			System.out.println("Current Speed is:"+currentSpeed+ " gear is: 4");
		}
		else if(braketype.contentEquals("medium"))
		{
			currentSpeed -= 25;
			currentSpeed = currentSpeed <= 0 ? 0 : currentSpeed;
			System.out.println("Current Speed is:"+currentSpeed+ " gear is: 3");
		}
		else if(braketype.contentEquals("low"))
		{
			currentSpeed -= 10;
			currentSpeed = currentSpeed <= 0 ? 0 : currentSpeed;
			System.out.println("Current Speed is:"+currentSpeed+ " gear is: 2");
		}
		else {
			System.out.println("Enter Valid Break Type");
		}
		
		if(currentSpeed <= 0)
		{
			stopEngine();
		}
	  }
	}
