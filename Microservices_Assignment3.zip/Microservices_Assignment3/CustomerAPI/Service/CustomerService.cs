﻿using CustomerAPI.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CustomerAPI.Service
{
    public class CustomerService
    {
        public List<Customer> GetCustomers()
        {
            var customers = new List<Customer>();
            for (int i = 1; i <= 7; i++)
            {
                customers.Add(new Customer
                {
                    CustomerId = i,
                    Name = $"Customer_{i}",
                    Email = $"Customer_{i}",
                    Phone = $"Customer_{i}",
                    Location = new Location
                    {
                        LocationId = i,
                        Address = $"Address_{i}",
                        PinCode = $"Pincode_{i}",
                        City = $"City_{i}",
                        State = $"State_{i}",
                        Country = $"Country_{i}"
                    },

                });
            }
            return customers;
        }
    }
}
