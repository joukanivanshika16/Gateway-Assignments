﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using CommonObjects.Models;
using Microsoft.Extensions.Logging;
using VehicleService.Services;

namespace VehicleAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DropDownController : ControllerBase
    {
        private readonly ILogger<DropDownController> _logger;

        public DropDownController(ILogger<DropDownController> logger)
        {
            _logger = logger;
        }
        [HttpGet, Route("GetServices")]
        public IEnumerable<DropdownDto> GetServices()
        {
            return new ServicesService().GetServices().Select(r => new DropdownDto { Id = r.ServiceId, Name = r.ServiceName });
        }
    }
}
