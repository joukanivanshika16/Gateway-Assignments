﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VehicleService.Enum;
using static VehicleService.Enum.ServiceEnum;

namespace VehicleService.Entites
{
    public class Service
    {
        public long ServiceId { get; set; }
        public string ServiceName { get; set; }
        public string ServiceDescription { get; set; }
        public double ServicePrice { get; set; }
        public ServiceEnum ServiceType { get; internal set; }
        public string TypeName => ServiceType.ToString();
        public long VehicleId { get; set; }
        
        
    }

    
}
