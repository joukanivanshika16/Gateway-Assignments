import java.util.Scanner;

public class FizzBuzz {
	/*In FizzBuzz if user will enter an input value
	 * If it is divisible by 3 then it will display user's FirstName
	 * If it is divisible by 5 then it will display user's LastName
	 * If it is divisible by 3 and 5 then it will display user's FirstName & LastName
	 */
	public static void main(String[] args) {
		//Variables
		String firstName="Vanshika";
		String lastName="Joukani";
		
		//Loops And Conditions
		do {
			Scanner sc = new Scanner(System.in);
			System.out.println("Please enter an integer number");
			int userInput=sc.nextInt();
			
			if(userInput % 3==0 && userInput % 5==0) {
				System.out.println(firstName+" "+lastName);
				break;
			}
			else if(userInput %3==0) {
				System.out.println(firstName);
			}
			else if(userInput % 5==0) {
				System.out.println(lastName);
			}
			else {
				System.out.println("Enter valid input");
			}
		}
		while(true);
	}
}
