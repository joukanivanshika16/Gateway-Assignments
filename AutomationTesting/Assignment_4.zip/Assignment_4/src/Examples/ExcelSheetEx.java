package Examples;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.concurrent.TimeUnit;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class ExcelSheetEx {
	/*This program will fetch the data from excel file named "InputFields.xlsx"
	*/
	
	public static void main(String[] args) throws InterruptedException, FileNotFoundException {
		String gcPath="./drivers/chromedriver.exe";
		String url="https://www.seleniumeasy.com/test/";
		System.setProperty("webdriver.chrome.driver", gcPath);
		 String fileName="InputFields.xlsx";
		 String sheetName="Vanshika Joukani";

	 	WebDriver gcDriver=new ChromeDriver();
		gcDriver.manage().window().maximize();
		gcDriver.get(url);
		gcDriver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        
        String popUpId="at-cv-lightbox-close";
        WebElement popUp = gcDriver.findElement(By.id(popUpId));
        popUp.click();
        
        String inputFormXpath = "//a[@class='dropdown-toggle']";
        WebElement inputForms = gcDriver.findElement(By.xpath(inputFormXpath));
        inputForms.click();
        
        String inputFormSubmitXpath="//ul[@class='dropdown-menu']//a[text()='Input Form Submit']";
        WebElement inputFormSubmit = gcDriver.findElement(By.xpath(inputFormSubmitXpath));
	    inputFormSubmit.click();
	    
		File file = new File("E:\\Gateway_QA"+"\\"+"InputFields.xlsx");
		FileInputStream inputStream = new FileInputStream(file);
		Workbook workbook = null;
		String fileExtensionName = fileName.substring(fileName.indexOf("."));
		
		if(fileExtensionName.equals(".xlsx")){
		    try {
				workbook = new XSSFWorkbook(inputStream);
			} catch (IOException e) {
				e.printStackTrace();
		}
	}
		Sheet sheet = workbook.getSheet(sheetName);
		int rowCount = sheet.getLastRowNum() - sheet.getFirstRowNum();
		System.out.println("Row Count:" + rowCount);
  
		for (int i = 1; i < rowCount+1; i++) {
			Row row = sheet.getRow(i);
			int cellNo = 0;
			
			String first_name="first_name";
		    WebElement firstName = gcDriver.findElement(By.name(first_name));
		    firstName.click();
		    firstName.clear();
		    firstName.sendKeys(row.getCell(cellNo).getStringCellValue());
		    
		    String last_name="last_name";
		    WebElement lastName = gcDriver.findElement(By.name(last_name));
		    lastName.click();
		    lastName.clear();
		    lastName.sendKeys(row.getCell(cellNo+1).getStringCellValue());
		    
		    String emailName = "email";
		    WebElement email = gcDriver.findElement(By.name(emailName));
		    email.click();
		    email.clear();
		    email.sendKeys(row.getCell(cellNo+2).getStringCellValue());    
		
		    String phoneName="phone";
		    WebElement phone = gcDriver.findElement(By.name(phoneName));
		    phone.click();
		    phone.clear();
		    phone.sendKeys(String.valueOf((long)row.getCell(cellNo+3).getNumericCellValue()));
		
		    String addressName="address";
		    WebElement address = gcDriver.findElement(By.name(addressName));
		    address.click();
		    address.clear();
		    address.sendKeys(row.getCell(cellNo+4).getStringCellValue());
		
		    String cityName="city";
		    WebElement city = gcDriver.findElement(By.name(cityName));
		    city.click();
		    city.clear();
		    city.sendKeys(row.getCell(cellNo+5).getStringCellValue());
		
		    String stateDDPath="select[name='state']";
			WebElement stateDD=gcDriver.findElement(By.cssSelector(stateDDPath));
			Select selectDD=new Select(stateDD);
			selectDD.selectByVisibleText(row.getCell(cellNo+6).getStringCellValue());

		    String zipName="zip";
		    WebElement zipCode = gcDriver.findElement(By.name(zipName));
		    zipCode.click();
		    zipCode.clear();
		    zipCode.sendKeys(String.valueOf((long)row.getCell(cellNo+7).getNumericCellValue()));
		
		    String websiteName="website";
		    WebElement website = gcDriver.findElement(By.name(websiteName));
		    website.click();
		    website.clear();
		    website.sendKeys(row.getCell(cellNo+8).getStringCellValue());
		    
		    boolean trueOrFalse = row.getCell(cellNo+9).getBooleanCellValue();
		    if(trueOrFalse) {
		    	String radiobtnXpathT="//input[@value='yes']";
			    WebElement radiobtnTrue = gcDriver.findElement(By.xpath(radiobtnXpathT));
			    radiobtnTrue.click();
		    }
		    else {
		    	String radioButtonXpathF ="//input[@value='no']";
		    	WebElement radiobtnFalse = gcDriver.findElement(By.xpath(radioButtonXpathF));
		    	radiobtnFalse.click();
		    }
		    
		    String descriptionName="comment";
		    WebElement description = gcDriver.findElement(By.name(descriptionName));
		    description.click();
		    description.clear();
		    description.sendKeys(row.getCell(cellNo+10).getStringCellValue());
		    
		    String btnSubmitCSS = "button.btn-default";
		    WebElement submitButton = gcDriver.findElement(By.cssSelector(btnSubmitCSS));
		    submitButton.click();
		    System.out.println(i +" number row is verifying.");
		}
	}
}
