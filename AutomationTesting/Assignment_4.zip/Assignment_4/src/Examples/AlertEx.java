package Examples;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class AlertEx {
	public static void main(String[] args) throws InterruptedException{
		String gcPath="./drivers/chromedriver.exe";
		String url="https://www.seleniumeasy.com/test/";
		System.setProperty("webdriver.chrome.driver", gcPath);

	 	WebDriver gcDriver=new ChromeDriver();
		gcDriver.manage().window().maximize();
		gcDriver.get(url);
		gcDriver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        
        String popUpId="at-cv-lightbox-close";
        WebElement popUp = gcDriver.findElement(By.id(popUpId));
        popUp.click();
        
        String alertAndModalsPath="//a[contains(text(),'Alerts & Modals')]";
		WebElement alertModals=gcDriver.findElement(By.xpath(alertAndModalsPath));
		alertModals.click();
		
		  String javascriptAlert="//a[contains(text(),'Javascript Alerts')]";
		  WebElement javascriptAlerts=gcDriver.findElement(By.xpath(javascriptAlert));
		  javascriptAlerts.click();
		  
		  String alertOKCSS="button[class='btn btn-default']";
		  WebElement alertOK=gcDriver.findElement(By.cssSelector(alertOKCSS));
		  alertOK.click();
		}
	}