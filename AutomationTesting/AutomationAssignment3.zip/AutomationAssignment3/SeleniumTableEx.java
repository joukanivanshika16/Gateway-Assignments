package SeleniumExample;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import java.util.List;

public class SeleniumTableEx {

	public static void main(String[] args) throws InterruptedException{
		 String gcPath="./drivers/chromedriver.exe";
		 String url="https://www.seleniumeasy.com/test/";
		 System.setProperty("webdriver.chrome.driver", gcPath);

		 	WebDriver gcDriver=new ChromeDriver();
			gcDriver.manage().window().maximize();
			gcDriver.get(url);
			
			
			Thread.sleep(5000);
			String popupId="at-cv-lightbox-close";
			WebElement popupClose=gcDriver.findElement(By.id(popupId));
			popupClose.click();
			Thread.sleep(2000);
			
			String inputFormsPath="//a[@class='dropdown-toggle']";
			WebElement inputForm=gcDriver.findElement(By.xpath(inputFormsPath));
			inputForm.click();
			
			String jquerySelectDD="//ul[@class='dropdown-menu']//a[text()='Input Form Submit']";
			WebElement inputFormSubmit=gcDriver.findElement(By.xpath(jquerySelectDD));
			inputFormSubmit.click();
			Thread.sleep(2000);
			
			String tableXpath="//a[text()='Table']";
			WebElement table=gcDriver.findElement(By.xpath(tableXpath));
			table.click();
			
			
			String tableDataSearchXpath="//ul[@id='treemenu']//a[text()='Table Data Search']";
			WebElement tableDataSearch=gcDriver.findElement(By.xpath(tableDataSearchXpath));
			tableDataSearch.click();
			Thread.sleep(2000);
			
			String inputId="task-table-filter";
			WebElement inputField=gcDriver.findElement(By.id(inputId));
			inputField.click();
			inputField.clear();
			inputField.sendKeys("John");
			
			String tableRow="//table[@id='task-table']/tbody/tr";
			List<WebElement> tableRows=gcDriver.findElements(By.xpath(tableRow));
			
			for(WebElement rows:tableRows)
			{
				List<WebElement> tds=rows.findElements(By.tagName("td"));
				String rowText=tds.get(2).getText();
				System.out.println("Row value:"+rowText);
		}
	}
			
	}

