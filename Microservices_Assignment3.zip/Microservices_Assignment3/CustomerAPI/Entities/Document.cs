﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CustomerAPI.Entities
{
    public class Document
    {
        public long DocumentId { get; set; }
        public string Description { get; set; }
        public long CustomerId { get; set; }
      
    }
}
