package multipleInheritance;

public interface mutant {
	/*Interface mutant has a method definition:mutantDetails and
	 * An Abstract method:personalityDetails*/
	
	public void mutantDetails(String name,String ability,String planet);
	abstract void personalityDetails(String personalities[]);
}
