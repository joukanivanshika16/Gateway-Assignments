import java.util.Random;
import java.util.Scanner;

public class GuessingGame {
	/*
	 * This is a Random Number Guessing Game.
	 * Compiler will pick any random number between 0-100
	 * User has to guess that number in only 10 tries
	 */
	
	public static void main(String[] args) {
	    //Variables
	    Random randomNumber = new Random();
	    Scanner sc = new Scanner(System.in);
	    int compilerGuess;
	    boolean playAgain;
	    int minValue=1;
	    int maxValue=100;
	    
	    //Logic and While Loop
	    do {
	        compilerGuess = randomNumber.nextInt(maxValue-minValue +1) + minValue;
	        playAgain = false;
	        GuessingGameLogic(compilerGuess);
	       
	        System.out.println("Would you like to play again?");
	        switch (sc.next()) {
	            case "yes":
	                playAgain = true;
	                break;
	            default:
	                break;
	        }
	    } 
	    while (playAgain);
	    System.out.println("Goodbye");
	}

	public static void GuessingGameLogic(int compilerGuess){
		int tries;
		boolean triesOver=false;
		Scanner sc = new Scanner(System.in);
		for(tries=1;tries<=10;tries++) {
			System.out.println("Please enter an integer betwen 1 and 100:");
			System.out.println("Enter Number 1:");
			int userGuess1 = sc.nextInt();
			System.out.println("Enter Number 2:");
			int userGuess2 = sc.nextInt();
			int userGuessSum=userGuess1+userGuess2;
         
			if(userGuessSum>100 || userGuessSum<1) {
				System.out.println("Alert! Please enter numbers between 1 to 100");
			}
  
			else if(userGuessSum==compilerGuess) {
				System.out.println("Congratulations You Won! Your number of tries was: " + tries + " and the number was: " + compilerGuess);
         	 break;
			}
			else if (userGuessSum < compilerGuess) {
				System.out.println("Your guess is too low!");
			} 
			else {
				System.out.println("Your guess is too high!");
         } 
     }
		if(tries>10) {
			triesOver=true;
			System.out.println("You Loss!!! Your numbers of tries are over and the number was: " + compilerGuess);
     }
}
}