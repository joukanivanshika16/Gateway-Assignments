package Examples;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class SeleniumProgressBarEx {
	/*This program will handle the Progress Bar by using
	 * Automation Testing*/

	public static void main(String[] args) throws Exception {
		
		 String gcPath="./drivers/chromedriver.exe";
		 String url="https://www.seleniumeasy.com/test/";
		 System.setProperty("webdriver.chrome.driver", gcPath);
		
		 WebDriver gcDriver=new ChromeDriver();
		 gcDriver.manage().window().maximize();
		 gcDriver.get(url);
		 WebDriverWait wait=new WebDriverWait(gcDriver, 10);
		 Thread.sleep(2000);
      
      	String popupId="at-cv-lightbox-close";
		WebElement popupClose=gcDriver.findElement(By.id(popupId));
		popupClose.click();
		Thread.sleep(2000);
      
		String progressBarXpath="//ul[@id='treemenu']//a[text()='Alerts & Modals']";
		WebElement progressBar=gcDriver.findElement(By.xpath(progressBarXpath));
		progressBar.click();
  
		String progressBarModelXpath = "//ul[@id='treemenu']//a[text()='Progress Bar Modal']";
		WebElement progressBarModel = gcDriver.findElement(By.xpath(progressBarModelXpath));
		progressBarModel.click();
		Thread.sleep(2000);
      
		String btnCSSPath1 ="button.btn-primary";
		WebElement btn1 = gcDriver.findElement(By.cssSelector(btnCSSPath1));
		btn1.click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("progress-bar")));
		WebElement loadingprogressBar = gcDriver.findElement(By.xpath("//h3[text()='Simple dialog - Autoclose after 2 seconds']"));
		System.out.println(loadingprogressBar.getText());
		wait.until(ExpectedConditions.invisibilityOfElementLocated(By.className("progress-bar")));
     
		Thread.sleep(2000);
		String btnCSSPath2 ="button.btn-success";
		WebElement btn2 = gcDriver.findElement(By.cssSelector(btnCSSPath2));
		btn2.click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("progress-bar")));
		WebElement customProgressBar = gcDriver.findElement(By.xpath("//h3[text()='Custom message']"));
		System.out.println(customProgressBar.getText());
		wait.until(ExpectedConditions.invisibilityOfElementLocated(By.className("progress-bar")));
      
		Thread.sleep(2000);
		String btnCSSPath3 ="button.btn-warning";
		WebElement btn3 = gcDriver.findElement(By.cssSelector(btnCSSPath3));
		btn3.click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("progress-bar")));
		WebElement alertProgressBar = gcDriver.findElement(By.xpath("//h3[text()='Hello Mr. Alert !']"));
		System.out.println(alertProgressBar.getText());
		wait.until(ExpectedConditions.invisibilityOfElementLocated(By.className("progress-bar")));
	}
}
