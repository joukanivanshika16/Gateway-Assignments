package inheritance;

import java.util.Scanner;

public class Vehicle {
	/*Vehicle is a Super Class in which
	 * there are two methods-VehicleDetails() & Price().
	 */
	
	//Variables
	static String vehicleType;
	static int noOfWheels;
	//Constructor
	public Vehicle() {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Vehicle Type");
		this.vehicleType=sc.next();
		System.out.println("Enter No Of Wheels ");
		this.noOfWheels=sc.nextInt();
	}
	
	//Methods
	public static void  VehicleDetails() {
		System.out.println("VEHICLES DETAILS");
		System.out.println("Vehicle Type: "+vehicleType);
		System.out.println("No Of Wheels: "+noOfWheels);
	}
	
	 static int Price(int showRoomPrice,int roadTax,int insurance ) {
		return showRoomPrice+roadTax+insurance;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		 new Vehicle(); 
		 VehicleDetails();
		int price= Price(5000,2000,10000);
		System.out.println("Total Price Of Vehicle: "+price);

	}

}
