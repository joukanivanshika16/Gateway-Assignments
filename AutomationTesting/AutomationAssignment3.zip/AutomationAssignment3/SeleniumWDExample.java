package Examples;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

 public class SeleniumWDExample {
	 /*This will automate different browsers(Chrome,Firefox,Edge)
	  * using different Web Drivers 
	  */
	
	static String gcPath="./drivers/chromedriver.exe";
	static String ffPath="./drivers/geckodriver.exe";
	static String edPath="./drivers/msedgedriver.exe";
	
	public static void main(String[] args) {
		String url="https://www.google.com/";
		SeleniumWDExample setBrowser=new SeleniumWDExample();
		
		WebDriver gcDriver=setBrowser.launchBrowser("chrome");
		gcDriver.manage().window().maximize();
		gcDriver.get(url);
		
		WebDriver ffDriver=setBrowser.launchBrowser("firefox");
		ffDriver.manage().window().maximize();
		ffDriver.get(url);
		
		WebDriver edgeDriver=setBrowser.launchBrowser("edge");
		edgeDriver.manage().window().maximize();
		edgeDriver.get(url);
	}
	
	public WebDriver launchBrowser(String browserName) {
		WebDriver driver=null;
		if(browserName.equalsIgnoreCase("chrome")) {
		System.setProperty("webdriver.chrome.driver", gcPath);
		driver= new ChromeDriver();
		}
		else if(browserName.equalsIgnoreCase("firefox")) {
			System.setProperty("webdriver.gecko.driver", ffPath);
			driver=new FirefoxDriver();
		}
		
		else if(browserName.equalsIgnoreCase("edge"))
		{
			System.setProperty("webdriver.edge.driver", edPath);
			driver=new EdgeDriver();
		}
		return driver;
	}
	void closeBrowser(WebDriver browserInstance) {
		browserInstance.quit();
	}
}