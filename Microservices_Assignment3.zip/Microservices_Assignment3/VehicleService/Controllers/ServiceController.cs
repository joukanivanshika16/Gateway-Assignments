﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using VehicleService.Entites;
using VehicleService.Services;

namespace ServiceAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ServiceController : ControllerBase
    {
        private readonly ILogger<ServiceController> _logger;

        public ServiceController(ILogger<ServiceController> logger)
        {
            _logger = logger;
        }

        [HttpGet]
        public IEnumerable<Service> GetServices()
        {
            return new ServicesService().GetServices();
        }


        [HttpGet, Route("GetService/{id}")]
        public IEnumerable<Service> GetService(long id)
        {
            return new ServicesService().GetServices(id: id);
        }
    }
}
