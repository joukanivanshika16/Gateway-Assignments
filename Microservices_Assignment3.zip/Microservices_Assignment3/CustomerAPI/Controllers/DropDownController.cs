﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using CommonObjects.Models;
using CustomerAPI.Service;

namespace CustomerAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DropDownController : ControllerBase
    {
        private readonly ILogger<DropDownController> _logger;


        public DropDownController(ILogger<DropDownController> logger)
        {
            _logger = logger;
        }


        [HttpGet, Route("GetDocuments")]
        public IEnumerable<DropdownDto> GetDocuments()
        {
            return new DocumentService().GetDocuments().Select(r => new DropdownDto { Id = r.DocumentId, Name = r.Description });
        }

        [HttpGet, Route("GetCustomers")]
        public IEnumerable<DropdownDto> GetCustomers()
        {
            return new CustomerService().GetCustomers().Select(r => new DropdownDto { Id = r.CustomerId, Name = r.Name });
        }
    }
}
