﻿using CustomerAPI.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CustomerAPI.Service
{
    public class DocumentService
    {
        public List<Document> GetDocuments(long? id = null)
        {
            var documents = new List<Document>();
            var customers = GetCustomers();

            if (id != null)
            {
                customers = customers.Where(r => r.CustomerId == id);
            }
            foreach (var customer in customers)
            {

                for (int i = 1; i <= 3; i++)
                {
                    documents.Add(new Document
                    {
                        DocumentId = i,
                        Description = $"Document_{i}",
                        CustomerId = customer.CustomerId,
                    });
                }

            }
            return documents;
        }

        private IEnumerable<Customer> GetCustomers()
        {
            var customers = new List<Customer>();
            for (int i = 1; i <= 3; i++)
            {
                customers.Add(new Customer
                {

                    CustomerId = i,
                    Name = $"Customer_{i}",
                    Email = $"Customer_{i}",
                    Phone = $"Phone_{i}",
                    Location = new Location
                    {
                        LocationId = i,
                        Address = $"Address_{i}",
                        PinCode = $"Pincode_{i}",
                        City = $"City_{i}",
                        State = $"State_{i}",
                        Country = $"Country_{i}"
                    },
                });
            }
            return customers;
        }
    }

}