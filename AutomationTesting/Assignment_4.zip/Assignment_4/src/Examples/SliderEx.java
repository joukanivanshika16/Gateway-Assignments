package Examples;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class SliderEx {
	/*This program will handle the Slider by using
	 * Automation Testing*/
	
	public static void main(String[] args) throws InterruptedException {
		
		String gcPath="./drivers/chromedriver.exe";
		String url="https://www.seleniumeasy.com/test/";
		System.setProperty("webdriver.chrome.driver", gcPath);

	 	WebDriver gcDriver=new ChromeDriver();
		gcDriver.manage().window().maximize();
		gcDriver.get(url);
		gcDriver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	  
	  String popUpId = "at-cv-lightbox-close"; 
	  WebElement popUp = gcDriver.findElement(By.id(popUpId)); popUp.click();
	  
	  String progressBarXpath = "//a[contains(text(),'Progress Bars')]"; 
	  WebElement progressBar = gcDriver.findElement(By.xpath(progressBarXpath));
	  progressBar.click();
	  
	  String slidersXpath ="//ul[@class='dropdown-menu']//a[text()='Drag & Drop Sliders']"; 
	  WebElement sliders = gcDriver.findElement(By.xpath(slidersXpath)); sliders.click();
	 
	  Thread.sleep(5000);
	  String defaultValue10Xpath = "//div[@id='slider1']//input[@type='range']";
	  WebElement defaultValue10 = gcDriver.findElement(By.xpath(defaultValue10Xpath));
	 
	  int sliderWidth = defaultValue10.getSize().getWidth();
	  int xCoord = defaultValue10.getLocation().getX();
	  System.out.println(sliderWidth+" " +xCoord);
	  Actions action = new Actions(gcDriver);
	  action.moveToElement(defaultValue10).clickAndHold().moveByOffset(20, 0).release().perform();
	  System.out.println(sliderWidth+ " " +defaultValue10.getLocation().getX());
	}
}
