package inheritance;

import java.util.Scanner;

public class Car extends Vehicle {
	/*Car is a Sub Class of Vehicle which will 
	 * Override the methods of Super Class-
	 * Apart from that it has its own two methods:-
	 * startEngine() & stopEngine().
	 */
	
	//Variables
	static String brandName;
	static String engineType;
	static int personCapacity;
	static String fuelType;
	static String vehicleColor;
	
	//Constructor
	public Car() {
		super();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Brand Name");
		this.brandName=sc.next();
		System.out.println("Enter Engine Type");
		this.engineType=sc.next();
		System.out.println("Enter Person Capacity");
		this.personCapacity=sc.nextInt();
		System.out.println("Enter Fuel Type");
		this.fuelType=sc.next();
		System.out.println("Enter Vehicle Color");
		this.vehicleColor=sc.next();
	}
	
	//Methods
	public static void  VehicleDetails() {
		System.out.println("VEHICLES DETAILS");
		System.out.println("Vehicle Type: "+vehicleType);
		System.out.println("No Of Wheels: "+noOfWheels);
		System.out.println("Brand Name:"+brandName);
		System.out.println("Engine Type:"+engineType);
		System.out.println("Person Capacity:"+personCapacity);
		System.out.println("Fuel Type:"+fuelType);
		System.out.println("vehicle Color:"+vehicleColor);
	}
	
	static int Price(int roadTax,int insurance,int deliveryCharge,int accessoriesPrice) {
			return roadTax+insurance+deliveryCharge+accessoriesPrice;
		}
		
	public static void startEngine() {
			System.out.println("Car Started!");
		}
		
	public static void stopEngine() {
			System.out.println("Car Stopped!");
		}
	public static void main(String[] args) {
		new Car();
		VehicleDetails();
		int price= Price(5000,2000,10000,5000);
		System.out.println("Total On Road Price Of Car: "+price);
		startEngine();
		stopEngine();
	}

}
