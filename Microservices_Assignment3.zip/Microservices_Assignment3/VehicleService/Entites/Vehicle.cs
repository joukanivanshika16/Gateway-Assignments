﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace VehicleService.Entites
{
    public class Vehicle
    {
        public Vehicle(){
}
        public long ServiceId { get; set; }
        public long VehicleId { get; set; }
        public string Description { get; set; }
        public string LicencePlate { get; set; }
        public string Brand { get; set; }
        public string Model { get; set; }
        public string Color { get; set; }
    }
}
