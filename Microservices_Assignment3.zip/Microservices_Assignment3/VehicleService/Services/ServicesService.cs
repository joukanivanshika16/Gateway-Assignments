﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VehicleService.Entites;
using VehicleService.Enum;

namespace VehicleService.Services
{
    public class ServicesService
    {
        public IEnumerable<Service> GetServices(long? id = null)
        {
            var services = new List<Service>();
            var vehicles = GetVehicles();
            if (id != null)
            {
                vehicles = vehicles.Where(r => r.VehicleId == id);
            }
            foreach (var vehicle in vehicles)
            {
                for (int i = 1; i <= 3; i++)
                {
                    services.Add(new Service
                    {
                        ServiceId = i,
                        ServiceName = $"Service_{i}",
                        ServiceDescription = $"Service_{i}",
                        ServicePrice = (double)i * 100.00,
                        ServiceType = ServiceEnum.MajorService,

                        VehicleId = vehicle.VehicleId,

                    });
                }
            }
            return services;
        }
        private IEnumerable<Vehicle> GetVehicles()
        {
            var vehicles = new List<Vehicle>();
            for (int i = 1; i <= 3; i++)
            {
                vehicles.Add(new Vehicle
                {
                    ServiceId = i,
                    VehicleId = i,
                    Description = $"Description_{i}",
                    LicencePlate = $"LicencePlate_{i}",
                    Brand = $"Brand_{i}",
                    Model = $"Model_{i}",
                    Color = $"Color_{i}",

                });
            }
            return vehicles;
        }

    }
}