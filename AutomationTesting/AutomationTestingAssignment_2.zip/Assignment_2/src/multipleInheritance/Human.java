package multipleInheritance;

public interface Human  {
	/*Interface Human has a method definition:humanDetails()*/
	
	public void humanDetails(String name,String skills[]);
}
