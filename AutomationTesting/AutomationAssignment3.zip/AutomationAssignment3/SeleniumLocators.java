package SeleniumExample;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;


public class SeleniumLocators {
	
	public static void main(String[] args) throws InterruptedException{
		 String gcPath="./drivers/chromedriver.exe";
		 String url="https://www.seleniumeasy.com/test/";
		 System.setProperty("webdriver.chrome.driver", gcPath);

		 	WebDriver gcDriver=new ChromeDriver();
			gcDriver.manage().window().maximize();
			gcDriver.get(url);
			
			Thread.sleep(5000);
			String popupId="at-cv-lightbox-close";
			WebElement popupClose=gcDriver.findElement(By.id(popupId));
			popupClose.click();
			Thread.sleep(2000);
			
			String inputFormsPath="//a[@class='dropdown-toggle']";
			WebElement inputForm=gcDriver.findElement(By.xpath(inputFormsPath));
			inputForm.click();
		
			
			String inputFormsSubmitPath="//ul[@class='dropdown-menu']//a[text()='Input Form Submit']";
			WebElement inputFormSubmit=gcDriver.findElement(By.xpath(inputFormsSubmitPath));
			inputFormSubmit.click();
			
			
			String firstName="first_name";
			WebElement fName=gcDriver.findElement(By.name(firstName));
			fName.click();
			fName.clear();
			fName.sendKeys("Vanshika");
			
			String lastName="last_name";
			WebElement lName=gcDriver.findElement(By.name(lastName));
			lName.click();
			lName.clear();
			lName.sendKeys("Joukani");
			
			
			String emailId="email";
			WebElement email=gcDriver.findElement(By.name(emailId));
			email.click();
			email.clear();
			email.sendKeys("test@mail.com");
			
			
			String phoneNo="phone";
			WebElement phone=gcDriver.findElement(By.name(phoneNo));
			phone.click();
			phone.clear();
			phone.sendKeys("0000000000");
			
			String Address="address";
			WebElement address=gcDriver.findElement(By.name(Address));
			address.click();
			address.clear();
			address.sendKeys("xyz");
			
			
			String City="city";
			WebElement city=gcDriver.findElement(By.name(City));
			city.click();
			city.clear();
			city.sendKeys("Ahmedabad");
		
			String stateDDPath="select[name='state']";
			WebElement stateDD=gcDriver.findElement(By.cssSelector(stateDDPath));
			Select selectDD=new Select(stateDD);
			selectDD.selectByIndex(5);
			Thread.sleep(2000);
			selectDD.selectByValue(" ");
			Thread.sleep(2000);
			selectDD.selectByVisibleText("Indiana");
			
			String zipName="zip";
			WebElement zipcode=gcDriver.findElement(By.name(zipName));
			zipcode.click();
			zipcode.clear();
			zipcode.sendKeys("000000");
			Thread.sleep(2000);
			
			String websiteName="website";
			WebElement website=gcDriver.findElement(By.name(websiteName));
			website.click();
			website.clear();
			website.sendKeys("www.google.com");
			
			
			WebElement radiobtn1=gcDriver.findElement(By.cssSelector("input[value='yes']"));
			WebElement radiobtn2=gcDriver.findElement(By.cssSelector("input[value='no']"));
			radiobtn2.click();
			
			String commentName="comment";		
			WebElement comments=gcDriver.findElement(By.name(commentName));
			comments.click();
			comments.clear();
			comments.sendKeys("xyz");
			
		    String submitButtonPath = "button.btn-default";
		    WebElement btnSubmit = gcDriver.findElement(By.cssSelector(submitButtonPath));
		    btnSubmit.click();

			gcDriver.quit();
			
				
	}	
}
	

