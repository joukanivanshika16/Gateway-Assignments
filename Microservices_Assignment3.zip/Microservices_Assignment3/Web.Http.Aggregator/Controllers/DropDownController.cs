﻿using CommonObjects.Models;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Web.Http.Aggregator.Util;


namespace Web.Http.Aggregator.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DropDownController : ControllerBase
    {
        private readonly ILogger<DropDownController> _logger;

        public DropDownController(ILogger<DropDownController> logger)
        {
            _logger = logger;
        }

        [HttpGet, Route("GetCustomers")]
        public async Task<IEnumerable<DropdownDto>> GetCustomers()
        {
            var customers = await HttpCall.GetRequest<List<DropdownDto>>("https://localhost:7340//DropDown/GetCustomers");
            var documents = await HttpCall.GetRequest<List<DropdownDto>>("https://localhost:7340//DropDown/GetDocuments");
            customers.AddRange(documents);
            return customers;
        }




    }
}
