package Examples;

import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotSelectableException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class DropDownEx {
	/*This program will handle the Drop Down by using
	 * Automation Testing*/
	public static void main(String[] args) throws InterruptedException{
		 String gcPath="./drivers/chromedriver.exe";
		 String url="https://www.seleniumeasy.com/test/";
		 System.setProperty("webdriver.chrome.driver", gcPath);

		 	WebDriver gcDriver=new ChromeDriver();
			gcDriver.manage().window().maximize();
			gcDriver.get(url);
			
			Thread.sleep(5000);
			String popupId="at-cv-lightbox-close";
			WebElement popupClose=gcDriver.findElement(By.id(popupId));
			popupClose.click();
			Thread.sleep(2000);
		
			String inputFormsPath="//a[@class='dropdown-toggle']";
			WebElement inputForm=gcDriver.findElement(By.xpath(inputFormsPath));
			inputForm.click();
			Thread.sleep(2000);
			
			String jquerySelectDD="//ul[@class='dropdown-menu']//a[text()='JQuery Select dropdown']";
			WebElement inputFormSubmit=gcDriver.findElement(By.xpath(jquerySelectDD));
			inputFormSubmit.click();
			Thread.sleep(2000);
			
			String countryId="country";
			WebElement countryDD=gcDriver.findElement(By.id(countryId));
			Select selectDD=new Select(countryDD);
			selectDD.selectByIndex(6);
			Thread.sleep(2000);
			
			WebElement stateDD=gcDriver.findElement(By.cssSelector("input.select2-search__field"));
			stateDD.click();
			stateDD.sendKeys("North");
			Thread.sleep(2000);
			
			String state1="//li[text()='North Dakota']";
			WebElement stateselect1=gcDriver.findElement(By.xpath(state1));
			stateselect1.click();
			Thread.sleep(2000);
			
			stateDD.click();
			stateDD.sendKeys("alabama");
			String state2="//li[text()='Alabama']";
			WebElement stateselect2=gcDriver.findElement(By.xpath(state2));
			stateselect2.click();
			Thread.sleep(2000);
			
			try {
	        WebElement disabledDD = gcDriver.findElement(By.xpath("//select[@class='js-example-disabled-results select2-hidden-accessible']"));
	        Select disabledStateDD = new Select(disabledDD);
	        disabledStateDD.selectByVisibleText("Guam");			
	        }
			catch(ElementNotSelectableException e) {
				System.out.println(e.getMessage());
			}
			
			String fileDD="files";
			Select categoryDd=new Select(gcDriver.findElement(By.id(fileDD)));
			categoryDd.selectByVisibleText("Java");
		}


}
